/**
 * BedCalibrationPanel.jsx
 *
 * PCB Surface Leveling — probes the PCB surface only (not the full bed).
 * Includes a guided flow: home → anchor PCB origin → auto-probe 5 points.
 *
 * Props
 * ─────
 *  machinePosition     { x, y, z }                live from App
 *  boardOutline        { minX, minY, width, height } from extractBoardOutline
 *  xf                  transform object (may be null)
 *  applyXf             bool
 *  isConnected         bool
 *  onSetPcbOrigin      (machinePos) => void        call App's setPcbOriginOffset
 *  onSendGcode         async (line: string) => void  wraps window.serial.writeLine
 *
 * Exports
 * ───────
 *  getZOffsetForPoint(x, y) → number
 *    Import and call this in AutomatedDispensingPanel before every dispense Z move.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { applyTransform } from '../lib/utils/transform2d.js';
import { useToast } from '../Toast.jsx';
import { fw } from '../lib/firmware/grblCommands.js';

const delay = ms => new Promise(r => setTimeout(r, ms));

// ─── Z-mesh interpolation (IDW) ──────────────────────────────────────────────
export function interpolateZ(mesh, px, py) {
  if (!mesh || mesh.length === 0) return 0;
  const cal = mesh.filter(p => p.zParam !== 0);
  if (cal.length === 0) return 0;
  if (cal.length === 1) return cal[0].zParam;
  let num = 0, den = 0;
  for (const pt of cal) {
    const d2 = (pt.x - px) ** 2 + (pt.y - py) ** 2;
    if (d2 < 1e-6) return pt.zParam;
    const w = 1 / d2;
    num += w * pt.zParam;
    den += w;
  }
  return den > 0 ? num / den : 0;
}

let _meshRef = [];
export function getZOffsetForPoint(x, y) { return interpolateZ(_meshRef, x, y); }

// ─── Flow steps ───────────────────────────────────────────────────────────────
const FLOW = {
  IDLE:       'idle',
  ANCHOR:     'anchor',   // user jogs to PCB BL corner
  PROBING:    'probing',  // auto-stepping through 5 points
  DONE:       'done',
};

// ─── Small reusable UI pieces ─────────────────────────────────────────────────
const Btn = ({ onClick, disabled, color = '#00c49a', textColor = '#000', children, style = {} }) => (
  <button onClick={onClick} disabled={disabled} style={{
    padding: '9px 14px', fontWeight: 'bold', fontSize: '0.88em',
    background: disabled ? '#333' : color,
    color: disabled ? '#666' : textColor,
    border: 'none', borderRadius: 5, cursor: disabled ? 'not-allowed' : 'pointer',
    ...style,
  }}>{children}</button>
);

const Field = ({ label, value, onChange, step, min, max, disabled, unit }) => (
  <div>
    <label style={{ color: '#888', display: 'block', marginBottom: 2, fontSize: '0.82em' }}>{label}</label>
    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <input type="number" value={value} step={step} min={min} max={max}
        disabled={disabled}
        onChange={e => onChange(parseFloat(e.target.value) || value)}
        style={{ flex: 1, padding: 5, background: '#1e1e2e', color: 'white', border: '1px solid #334', borderRadius: 3 }} />
      {unit && <span style={{ color: '#666', fontSize: '0.82em' }}>{unit}</span>}
    </div>
  </div>
);

// ─── Inline jog panel (used during ANCHOR step) ───────────────────────────────
function InlineJog({ onSend, disabled, xySpeed = 500, zSpeed = 300 }) {
  const [step, setStep] = useState(1);
  const send = useCallback(async (cmd) => {
    try { await onSend(cmd); } catch (e) { console.error('[Jog]', e); }
  }, [onSend]);

  const jogXY = (axis, dir) => {
    const dist = (dir * step).toFixed(3);
    send(`$J=G91 ${axis}${dist} F${xySpeed}`);
  };
  const jogZ  = (dir) => {
    const dist = (dir * 0.5).toFixed(3);
    send(`$J=G91 Z${dist} F${zSpeed}`);
  };

  const btn = (label, onClick, w = 44) => (
    <button onClick={onClick} disabled={disabled}
      style={{ width: w, height: 36, background: '#1e2a3a', color: '#9cf', border: '1px solid #334',
        borderRadius: 4, cursor: disabled ? 'not-allowed' : 'pointer', fontSize: '0.8em', fontWeight: 'bold' }}>
      {label}
    </button>
  );

  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, flexWrap: 'wrap' }}>
        <span style={{ fontSize: '0.78em', color: '#888' }}>Step:</span>
        {[0.1, 0.5, 1, 5, 10].map(s => (
          <button key={s} onClick={() => setStep(s)}
            style={{ padding: '3px 8px', fontSize: '0.78em', background: step === s ? '#00c49a' : '#1e1e1e',
              color: step === s ? '#000' : '#aaa', border: '1px solid #444', borderRadius: 3, cursor: 'pointer' }}>
            {s}mm
          </button>
        ))}
      </div>
      {/* XY grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '44px 44px 44px', gridTemplateRows: '36px 36px 36px', gap: 3 }}>
        <div />
        {btn('Y+', () => jogXY('Y',  1))}
        <div />
        {btn('X-', () => jogXY('X', -1))}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: '#111', borderRadius: 4, fontSize: '0.7em', color: '#555' }}>XY</div>
        {btn('X+', () => jogXY('X',  1))}
        <div />
        {btn('Y-', () => jogXY('Y', -1))}
        <div />
      </div>
      {/* Z */}
      <div style={{ display: 'flex', gap: 3, marginTop: 3 }}>
        {btn('Z+', () => jogZ( 1), 66)}
        {btn('Z-', () => jogZ(-1), 66)}
        <span style={{ fontSize: '0.72em', color: '#555', alignSelf: 'center', marginLeft: 4 }}>0.5mm / click</span>
      </div>
    </div>
  );
}

// ─── Height Map Visualizer ───────────────────────────────────────────────────
function HeightMapVisualizer({ mesh, boardOutline }) {
  if (!mesh || mesh.length === 0) return null;
  const calibrated = mesh.filter(p => p.zParam !== 0);
  if (calibrated.length === 0) return null;

  const SVG_W = 280, SVG_H = 180, PAD = 28;

  // Use design-space positions for layout; fall back to machine coords
  const pts = mesh.map(p => ({ ...p, px: p.designX ?? p.x, py: p.designY ?? p.y }));

  // Board outline bounds
  let minX, maxX, minY, maxY;
  if (boardOutline) {
    minX = boardOutline.minX ?? 0;
    minY = boardOutline.minY ?? 0;
    maxX = boardOutline.maxX ?? (minX + (boardOutline.width  ?? 100));
    maxY = boardOutline.maxY ?? (minY + (boardOutline.height ?? 100));
  } else {
    minX = Math.min(...pts.map(p => p.px));
    maxX = Math.max(...pts.map(p => p.px));
    minY = Math.min(...pts.map(p => p.py));
    maxY = Math.max(...pts.map(p => p.py));
  }
  const rangeX = maxX - minX || 1;
  const rangeY = maxY - minY || 1;

  // Convert design coords → SVG pixel coords
  const toSvg = (px, py) => ({
    x: PAD + ((px - minX) / rangeX) * (SVG_W - 2 * PAD),
    y: PAD + ((py - minY) / rangeY) * (SVG_H - 2 * PAD),
  });

  // Z → colour: blue (low) → green (mid) → red (high)
  const zVals  = calibrated.map(p => p.zParam);
  const zMin   = Math.min(...zVals);
  const zMax   = Math.max(...zVals);
  const zRange = zMax - zMin || 0.001;
  const zToColor = z => {
    const t = Math.max(0, Math.min(1, (z - zMin) / zRange));
    let r, g, b;
    if (t < 0.5) {
      const s = t * 2;
      r = 0; g = Math.round(120 + s * 80); b = Math.round(255 - s * 155);
    } else {
      const s = (t - 0.5) * 2;
      r = Math.round(s * 255); g = Math.round(200 - s * 150); b = Math.round(100 - s * 100);
    }
    return `rgb(${r},${g},${b})`;
  };

  return (
    <div style={{ marginTop: 14 }}>
      <div style={{ fontSize: '0.82em', color: '#8b949e', marginBottom: 6, fontWeight: 600, letterSpacing: '0.03em' }}>
        📊 Surface Height Map
      </div>
      <svg width={SVG_W} height={SVG_H}
        style={{ background: '#0d1117', borderRadius: 8, border: '1px solid #21262d', display: 'block' }}>

        {/* Board outline */}
        <rect x={PAD} y={PAD} width={SVG_W - 2 * PAD} height={SVG_H - 2 * PAD}
          fill="rgba(48,54,61,0.25)" stroke="#30363d" strokeWidth="1.5" strokeDasharray="5,3" rx="2" />

        {/* Connecting lines between every pair of calibrated points */}
        {calibrated.map((a, i) =>
          calibrated.slice(i + 1).map((b, j) => {
            const sa = toSvg(a.designX ?? a.x, a.designY ?? a.y);
            const sb = toSvg(b.designX ?? b.x, b.designY ?? b.y);
            const midColor = zToColor((a.zParam + b.zParam) / 2);
            return <line key={`ln-${i}-${j}`}
              x1={sa.x} y1={sa.y} x2={sb.x} y2={sb.y}
              stroke={midColor} strokeWidth="1.5" strokeOpacity="0.35" />;
          })
        )}

        {/* Probe point circles + labels */}
        {pts.map(pt => {
          const s   = toSvg(pt.px, pt.py);
          const done  = pt.zParam !== 0;
          const col   = done ? zToColor(pt.zParam) : '#30363d';
          const shortName = pt.name
            .replace('Bottom-Left', 'BL').replace('Bottom-Right', 'BR')
            .replace('Top-Left',    'TL').replace('Top-Right',    'TR')
            .replace('Center',      'CTR');
          return (
            <g key={pt.id}>
              {/* Outer glow ring */}
              <circle cx={s.x} cy={s.y} r={16} fill={col} fillOpacity={done ? 0.12 : 0.04}
                stroke={col} strokeWidth={done ? 1.5 : 0.5} strokeOpacity={done ? 0.6 : 0.2} />
              {/* Centre dot */}
              <circle cx={s.x} cy={s.y} r={5} fill={done ? col : '#21262d'}
                stroke={done ? col : '#30363d'} strokeWidth="1" />
              {/* Point name above */}
              <text x={s.x} y={s.y - 20} textAnchor="middle"
                fill="#8b949e" fontSize="9" fontFamily="monospace">
                {shortName}
              </text>
              {/* Z value below */}
              {done && (
                <text x={s.x} y={s.y + 24} textAnchor="middle"
                  fill={col} fontSize="9" fontFamily="monospace" fontWeight="bold">
                  {pt.zParam.toFixed(3)}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {/* Gradient legend */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 7,
        fontSize: '0.73em', color: '#8b949e', width: SVG_W }}>
        <span style={{ color: 'rgb(0,120,255)', flexShrink: 0 }}>▬ Low</span>
        <div style={{ flex: 1, height: 5, borderRadius: 3,
          background: 'linear-gradient(to right,rgb(0,120,255),rgb(0,200,100),rgb(255,50,0))' }} />
        <span style={{ color: 'rgb(255,50,0)', flexShrink: 0 }}>High ▬</span>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', width: SVG_W,
        fontSize: '0.70em', color: '#555', marginTop: 2 }}>
        <span>{zMin.toFixed(3)} mm</span>
        <span>{zMax.toFixed(3)} mm</span>
      </div>
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────────
export default function BedCalibrationPanel({
  machinePosition = { x: 0, y: 0, z: 0 },
  boardOutline,
  xf,
  applyXf,
  isConnected,
  onSetPcbOrigin,
}) {

  const toast = useToast();

  // ── Mesh ────────────────────────────────────────────────────────────────────
  const [mesh, setMesh] = useState(() => {
    try {
      const s = JSON.parse(localStorage.getItem('bedLevelMesh'));
      if (Array.isArray(s) && s.length > 0) return s;
    } catch (_) {}
    return [];
  });
  useEffect(() => { _meshRef = mesh; }, [mesh]);
  useEffect(() => { localStorage.setItem('bedLevelMesh', JSON.stringify(mesh)); }, [mesh]);

  // ── Probe settings ──────────────────────────────────────────────────────────
  const ls = (k, d) => { try { return parseFloat(localStorage.getItem(k) ?? d); } catch { return parseFloat(d); } };
  const [probeStartZ,   setProbeStartZ]   = useState(() => ls('probeStartZ',   '3'));
  const [stepSize,      setStepSize]      = useState(() => ls('probeStepSize', '0.1'));
  const [probeSpeed,    setProbeSpeed]    = useState(() => ls('probeSpeed',    '60'));
  const [xySpeed,       setXySpeed]       = useState(() => ls('bedProbeXySpeed', '300'));
  const [maxDepth,      setMaxDepth]      = useState(() => ls('probeMaxDepth', '-5'));
  const [dispensingGap, setDispensingGap] = useState(() => ls('dispensingGap', '0.1'));
  const [liftHeight,    setLiftHeight]    = useState(() => ls('liftHeight',    '5'));
  const [edgeInset,     setEdgeInset]     = useState(() => ls('pcbProbeEdgeInset', '5'));

  useEffect(() => { localStorage.setItem('probeStartZ',        String(probeStartZ));   }, [probeStartZ]);
  useEffect(() => { localStorage.setItem('probeStepSize',      String(stepSize));      }, [stepSize]);
  useEffect(() => { localStorage.setItem('probeSpeed',         String(probeSpeed));    }, [probeSpeed]);
  useEffect(() => { localStorage.setItem('bedProbeXySpeed',    String(xySpeed));       }, [xySpeed]);
  useEffect(() => { localStorage.setItem('probeMaxDepth',      String(maxDepth));      }, [maxDepth]);
  useEffect(() => { localStorage.setItem('dispensingGap',      String(dispensingGap)); }, [dispensingGap]);
  useEffect(() => { localStorage.setItem('liftHeight',         String(liftHeight));    }, [liftHeight]);
  useEffect(() => { localStorage.setItem('pcbProbeEdgeInset',  String(edgeInset));     }, [edgeInset]);

  // ── Flow state ──────────────────────────────────────────────────────────────
  const [flowStep,      setFlowStep]      = useState(FLOW.IDLE);
  const [probeMode,     setProbeMode]     = useState('auto');   // 'auto' | 'manual'
  const [statusMsg,     setStatus]        = useState('');
  const [progress,      setProgress]      = useState(0);
  const [currentPtIdx,  setCurrentPtIdx]  = useState(-1);
  const [pcbOrigin,     setPcbOrigin]     = useState(null);     // machine coords of PCB (0,0)

  // Manual mode
  const [manualIdx,     setManualIdx]     = useState(-1);
  const [manualStatus,  setManualStatus]  = useState('Idle.');

  const abortRef    = useRef(false);
  const mPosRef     = useRef(machinePosition);
  useEffect(() => { mPosRef.current = machinePosition; }, [machinePosition]);

  // ── GRBL communication & state management ──────────────────────────────────
  const ackQueue = useRef([]);
  const grblStateRef = useRef('Idle');
  const probeTriggeredRef = useRef(false);
  const firmwareFaultRef = useRef(null);

  // Subscribe to serial stream for GRBL ACKs ('ok'), real-time status (<Idle...|Pn:Z>), and alarms
  useEffect(() => {
    if (!window.serial?.onData) return;
    const unsub = window.serial.onData((line) => {
      const trimmed = line.trim();

      // Check for ACK
      const isAck = trimmed === 'ok' || trimmed.startsWith('ok') || /^ok\b/i.test(trimmed);
      if (isAck) {
        const entry = ackQueue.current.shift();
        if (entry) entry.resolve(true);
      }

      // Check for GRBL real-time status: <Idle|MPos:...> or <Run|...>
      const statusMatch = trimmed.match(/<([A-Za-z]+)\|/);
      if (statusMatch) {
        grblStateRef.current = statusMatch[1];
        // Auto-recover from Feed Hold if controller entered Hold state
        if (statusMatch[1] === 'Hold') {
          if (window.serial?.write) window.serial.write('~').catch(() => {});
        }
      }

      // Check for probe pin in status or probe response [PRB:...:1]
      if (/\|?Pn:[A-Za-z]*(Z|P)/i.test(trimmed) || /\[PRB:.*:1\]/i.test(trimmed)) {
        probeTriggeredRef.current = true;
      } else if (trimmed.startsWith('<') && !/\|Pn:/i.test(trimmed)) {
        probeTriggeredRef.current = false;
      }

      // Detect Alarm or Error
      if (/^ALARM[:\s]*\d+/i.test(trimmed) || trimmed === '!!' || /<Alarm/i.test(trimmed)) {
        firmwareFaultRef.current = trimmed;
        const pending = ackQueue.current.splice(0);
        for (const entry of pending) {
          entry.reject(new Error(`GRBL Alarm: ${trimmed}`));
        }
      } else if (/^error[:\s]*\d+/i.test(trimmed)) {
        const entry = ackQueue.current.shift();
        if (entry) entry.reject(new Error(`GRBL Error: ${trimmed}`));
      }
    });

    // Also listen for probe DOM events from SerialPanel's bridge
    const onTrig = () => { probeTriggeredRef.current = true; };
    const onOpen = () => { probeTriggeredRef.current = false; };
    window.addEventListener('endstop-z-probe-triggered', onTrig);
    window.addEventListener('endstop-z-probe-open', onOpen);

    return () => {
      if (typeof unsub === 'function') unsub();
      window.removeEventListener('endstop-z-probe-triggered', onTrig);
      window.removeEventListener('endstop-z-probe-open', onOpen);
    };
  }, []);

  // ── Send helper: waits for controller ACK ('ok') ────────────────────────────
  const sendGcodeWait = useCallback(async (cmd, timeoutMs = 15000) => {
    if (abortRef.current) throw new Error('Operation aborted');
    if (!window.serial?.writeLine) return;

    const trimmed = cmd.trim();
    if (!trimmed) return;

    // Real-time single byte commands (write directly without waiting for ok)
    if (trimmed === '?' || trimmed === fw.statusQuery) {
      if (window.serial.write) await window.serial.write(fw.statusQuery);
      else await window.serial.writeLine(fw.statusQuery);
      return;
    }
    if (trimmed === '!' || trimmed === fw.pause) {
      if (window.serial.write) await window.serial.write(fw.pause);
      else await window.serial.writeLine(fw.pause);
      return;
    }
    if (trimmed === '~' || trimmed === fw.resume) {
      if (window.serial.write) await window.serial.write(fw.resume);
      else await window.serial.writeLine(fw.resume);
      return;
    }
    if (trimmed === '\x18' || trimmed === fw.reset) {
      if (window.serial.write) await window.serial.write(fw.reset);
      else await window.serial.writeLine(fw.reset);
      return;
    }

    const lines = trimmed.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      if (abortRef.current) throw new Error('Operation aborted');
      if (firmwareFaultRef.current) {
        throw new Error(`Machine fault: ${firmwareFaultRef.current}`);
      }

      await new Promise((resolve, reject) => {
        let timer = null;
        const entry = {
          resolve: () => {
            if (timer) clearTimeout(timer);
            resolve();
          },
          reject: (err) => {
            if (timer) clearTimeout(timer);
            reject(err);
          }
        };
        ackQueue.current.push(entry);

        timer = setTimeout(() => {
          const idx = ackQueue.current.indexOf(entry);
          if (idx !== -1) ackQueue.current.splice(idx, 1);
          console.warn(`[BedCalibration] Timeout waiting for ok on: ${line}`);
          resolve();
        }, timeoutMs);

        window.serial.writeLine(line).catch(err => {
          if (timer) clearTimeout(timer);
          const idx = ackQueue.current.indexOf(entry);
          if (idx !== -1) ackQueue.current.splice(idx, 1);
          reject(err);
        });
      });
    }
  }, []);

  // Backwards-compatible send alias
  const send = sendGcodeWait;

  // ── Wait for GRBL motion to complete and state to become 'Idle' ─────────────
  const waitForIdle = useCallback(async (maxWaitMs = 15000) => {
    const start = Date.now();
    grblStateRef.current = 'Busy';
    await delay(120);

    while (Date.now() - start < maxWaitMs) {
      if (abortRef.current) throw new Error('Operation aborted');
      if (window.serial?.write) await window.serial.write(fw.statusQuery);
      else if (window.serial?.writeLine) await window.serial.writeLine(fw.statusQuery);

      await delay(80);
      if (grblStateRef.current === 'Idle') return true;
    }
    return true;
  }, []);

  // ── Coordinate mapping: design → machine ────────────────────────────────────
  const toMachine = useCallback((designPt, origin) => {
    // If we have a full fiducial transform, use it
    if (xf && applyXf) return applyTransform(xf, designPt);
    // Otherwise offset by the captured pcbOrigin
    const o = origin || pcbOrigin || { x: 0, y: 0 };
    return { x: o.x + designPt.x, y: o.y + designPt.y };
  }, [xf, applyXf, pcbOrigin]);

  // ── Build 5 probe points from boardOutline + captured origin ────────────────
  const buildProbePoints = useCallback((origin) => {
    if (!boardOutline) return null;

    const minX = boardOutline.minX ?? 0;
    const minY = boardOutline.minY ?? 0;
    const maxX = boardOutline.maxX ?? (minX + (boardOutline.width  ?? 100));
    const maxY = boardOutline.maxY ?? (minY + (boardOutline.height ?? 100));
    const w = maxX - minX, h = maxY - minY;
    const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
    const ins = Math.min(edgeInset, w * 0.4, h * 0.4); // safety clamp

    const designPts = [
      { id: 'BL', name: 'Bottom-Left',  x: minX + ins, y: minY + ins },
      { id: 'BR', name: 'Bottom-Right', x: maxX - ins, y: minY + ins },
      { id: 'TR', name: 'Top-Right',    x: maxX - ins, y: maxY - ins },
      { id: 'TL', name: 'Top-Left',     x: minX + ins, y: maxY - ins },
      { id: 'C',  name: 'Center',       x: cx,         y: cy         },
    ];

    return designPts.map(p => {
      const m = toMachine(p, origin);
      return {
        id: p.id, name: p.name,
        designX: p.x, designY: p.y,
        x: parseFloat(m.x.toFixed(3)),
        y: parseFloat(m.y.toFixed(3)),
        zParam: 0,
      };
    });
  }, [boardOutline, edgeInset, toMachine]);

  // ── Validate probe points stay within bed (235×235) ─────────────────────────
  const BED_MAX = 235;
  const validatePoints = (pts) => {
    const bad = pts.filter(p => p.x < 0 || p.y < 0 || p.x > BED_MAX || p.y > BED_MAX);
    return bad;
  };

  // ─────────────────────────────────────────────────────────────────────────────
  // FLOW STEP 1: Start — check preconditions then enter ANCHOR step
  // ─────────────────────────────────────────────────────────────────────────────
  const startLevelingFlow = useCallback(() => {
    if (!isConnected)  { toast.warning('Connect the machine first.'); return; }
    if (!boardOutline) { toast.warning('Load a Gerber board outline file first (must include an outline/edge layer).'); return; }

    abortRef.current = false;
    firmwareFaultRef.current = null;
    setProgress(0);
    setCurrentPtIdx(-1);
    setPcbOrigin(null);
    setMesh([]);

    setFlowStep(FLOW.ANCHOR);
    setStatus(
      'Jog the nozzle to the BOTTOM-LEFT corner of your PCB. ' +
      'The nozzle tip should just touch the board surface at that corner. ' +
      'Then click "Confirm PCB Origin".'
    );
  }, [isConnected, boardOutline]);

  // ─────────────────────────────────────────────────────────────────────────────
  // FLOW STEP 2: User confirms the PCB origin (nozzle is physically at BL corner)
  // ─────────────────────────────────────────────────────────────────────────────
  const confirmPcbOrigin = useCallback(async () => {
    const pos = mPosRef.current;
    if (!pos) { toast.warning('Machine position not available — is the machine connected and homed?'); return; }

    // Capture current machine position as the PCB (0,0) anchor
    const origin = { x: pos.x, y: pos.y, z: pos.z };
    setPcbOrigin(origin);

    // Tell App.jsx so the rest of the app (pad distances, path planning, etc.) stays in sync
    if (onSetPcbOrigin) onSetPcbOrigin(origin);

    // Build the 5 probe points now that we know the origin
    const pts = buildProbePoints(origin);
    if (!pts) { toast.error('Could not compute probe points — check board outline.'); return; }

    // Safety: ensure all points are within bed travel
    const outOfBounds = validatePoints(pts);
    if (outOfBounds.length > 0) {
      const names = outOfBounds.map(p => p.name).join(', ');
      if (!confirm(
        `Warning: these probe points exceed bed limits (${BED_MAX}×${BED_MAX}mm):\n${names}\n\n` +
        `This can happen if the PCB origin is placed near the bed edge.\n` +
        `Move machine to a better position or reduce Edge Inset. Continue anyway?`
      )) return;
    }

    setMesh(pts);
    setStatus(`PCB origin set at machine (${origin.x.toFixed(2)}, ${origin.y.toFixed(2)}). ` +
              `${pts.length} probe points generated. Ready to probe.`);

    // Lift nozzle to safe height before probing begins
    await sendGcodeWait(fw.absMode);
    await sendGcodeWait(`G1 Z${liftHeight} F300`);
    await waitForIdle(6000);

    if (probeMode === 'auto') {
      setFlowStep(FLOW.PROBING);
      runAutoProbe(pts, origin);
    } else {
      setFlowStep(FLOW.PROBING);
      runManualProbe(pts, 0);
    }
  }, [buildProbePoints, liftHeight, onSetPcbOrigin, probeMode, sendGcodeWait, waitForIdle]);

  // ─────────────────────────────────────────────────────────────────────────────
  // Single-point auto probe
  // ─────────────────────────────────────────────────────────────────────────────
  const probeOnePoint = useCallback(async (ptName) => {
    const msPerStep = Math.max(80, Math.ceil((stepSize / probeSpeed) * 60 * 1000) + 80);

    // Confirm endstop open at start height
    setStatus(`[${ptName}] Checking sensor state at Z=${probeStartZ}…`);
    if (window.serial?.write) await window.serial.write(fw.probeQuery);
    await delay(150);

    if (probeTriggeredRef.current) {
      setStatus(`⚠️ [${ptName}] Sensor already triggered at Z=${probeStartZ} — increase Start Z.`);
      return null;
    }

    let z = probeStartZ;
    setStatus(`[${ptName}] Stepping down from Z=${probeStartZ}…`);

    while (z > maxDepth) {
      if (abortRef.current) return null;
      z = parseFloat((z - stepSize).toFixed(4));
      await sendGcodeWait(`G1 Z${z} F${probeSpeed}`);
      await delay(msPerStep);

      // Query sensor status
      if (window.serial?.write) await window.serial.write(fw.probeQuery);
      await delay(60);

      if (probeTriggeredRef.current) {
        console.log(`✅ Contact at Z=${z} for ${ptName}`);
        return z;
      }
      setStatus(`[${ptName}] Z=${z.toFixed(3)} — stepping…`);
    }

    setStatus(`⚠️ [${ptName}] Reached max depth (${maxDepth}) without contact.`);
    return null;
  }, [stepSize, probeSpeed, probeStartZ, maxDepth, sendGcodeWait]);

  // ─────────────────────────────────────────────────────────────────────────────
  // FLOW STEP 3a: Full auto-probe loop through all 5 points
  // ─────────────────────────────────────────────────────────────────────────────
  const runAutoProbe = useCallback(async (pts, _origin) => {
    const serial = window.serial;
    if (!serial?.writeLine) return;

    abortRef.current = false;
    firmwareFaultRef.current = null;
    const updated = pts.map(p => ({ ...p, zParam: 0 }));

    try {
      await sendGcodeWait(fw.unitsMm); // G21
      await sendGcodeWait(fw.absMode); // G90

      for (let i = 0; i < pts.length; i++) {
        if (abortRef.current) break;
        const pt = pts[i];
        setCurrentPtIdx(i);

        // Move to safe Z, then travel to XY smoothly at xySpeed
        setStatus(`Moving to ${pt.name} (X${pt.x.toFixed(2)} Y${pt.y.toFixed(2)})…`);
        await sendGcodeWait(`G1 Z${probeStartZ} F300`);
        await waitForIdle(6000);

        await sendGcodeWait(`G1 X${pt.x.toFixed(3)} Y${pt.y.toFixed(3)} F${xySpeed}`);
        await waitForIdle(20000);

        const probedZ = await probeOnePoint(pt.name);

        if (probedZ === null) {
          abortRef.current = true;
          break;
        }

        // Store surface Z + gap as the dispense Z for this location
        updated[i] = { ...updated[i], zParam: parseFloat((probedZ + dispensingGap).toFixed(4)) };
        setMesh([...updated]);

        setStatus(`✅ ${pt.name}: surface Z=${probedZ.toFixed(3)}, dispense Z=${updated[i].zParam.toFixed(3)}. Retracting…`);
        await sendGcodeWait(`G1 Z${probeStartZ} F300`);
        await waitForIdle(6000);
        setProgress(Math.round(((i + 1) / pts.length) * 100));
      }

      if (!abortRef.current) {
        // Return to PCB origin (BL corner) at safe height
        await sendGcodeWait(`G1 Z${liftHeight} F300`);
        await waitForIdle(6000);
        await sendGcodeWait(`G1 X${pts[0].x.toFixed(3)} Y${pts[0].y.toFixed(3)} F${xySpeed}`);
        await waitForIdle(20000);
        setFlowStep(FLOW.DONE);
        setStatus(`✅ PCB leveling complete! ${pts.length} points probed. Z-compensation is now active.`);
      } else {
        setStatus('⚠️ Probing aborted.');
        setFlowStep(FLOW.IDLE);
      }

    } catch (err) {
      console.error('[AutoProbe]', err);
      setStatus('❌ Error: ' + err.message);
      setFlowStep(FLOW.IDLE);
    } finally {
      setCurrentPtIdx(-1);
    }
  }, [probeStartZ, liftHeight, xySpeed, dispensingGap, probeOnePoint, sendGcodeWait, waitForIdle]);

  // ─────────────────────────────────────────────────────────────────────────────
  // FLOW STEP 3b: Manual probe — drive to point, user jogs Z, clicks Save
  // ─────────────────────────────────────────────────────────────────────────────
  const runManualProbe = useCallback(async (pts, idx) => {
    if (idx >= pts.length) {
      await sendGcodeWait(fw.absMode);
      await sendGcodeWait(`G1 Z${liftHeight} F300`);
      await waitForIdle(6000);
      setFlowStep(FLOW.DONE);
      setStatus('✅ Manual leveling complete!');
      setManualIdx(-1);
      return;
    }
    const pt = pts[idx];
    setManualIdx(idx);
    setCurrentPtIdx(idx);
    setManualStatus(`Moving to ${pt.name}…`);
    await sendGcodeWait(fw.absMode);
    await sendGcodeWait(`G1 Z${probeStartZ} F300`);
    await waitForIdle(6000);
    await sendGcodeWait(`G1 X${pt.x.toFixed(3)} Y${pt.y.toFixed(3)} F${xySpeed}`);
    await waitForIdle(20000);
    setManualStatus(`Jog nozzle down until it JUST touches the PCB at ${pt.name}, then click Save Z.`);
  }, [probeStartZ, liftHeight, xySpeed, sendGcodeWait, waitForIdle]);

  // Mesh ref needed inside saveManualZ closure
  const meshRef = useRef(mesh);
  useEffect(() => { meshRef.current = mesh; }, [mesh]);

  const saveManualZ = useCallback(async () => {
    const pos = mPosRef.current;
    if (!pos) { toast.warning('Machine position unavailable.'); return; }
    const i = manualIdx;
    const dispZ = parseFloat((pos.z + dispensingGap).toFixed(4));

    setMesh(prev => {
      const n = [...prev];
      n[i] = { ...n[i], zParam: dispZ };
      return n;
    });

    setProgress(Math.round(((i + 1) / meshRef.current.length) * 100));
    // Advance to next point
    await runManualProbe(meshRef.current, i + 1);
  }, [manualIdx, dispensingGap, runManualProbe]);

  // ─────────────────────────────────────────────────────────────────────────────
  // Abort
  // ─────────────────────────────────────────────────────────────────────────────
  const abortFlow = useCallback(async () => {
    abortRef.current = true;
    firmwareFaultRef.current = null;
    try {
      if (window.serial?.write) await window.serial.write('\x85'); // Cancel GRBL jog
      await delay(50);
      if (window.serial?.write) await window.serial.write(fw.pause); // Feed hold '!'
      await delay(100);
      if (window.serial?.write) await window.serial.write(fw.reset); // Soft reset \x18
      await delay(250);
      if (window.serial?.writeLine) await window.serial.writeLine(fw.unlock); // Unlock $X
      await delay(150);
      if (window.serial?.writeLine) await window.serial.writeLine(`${fw.absMode}\n${fw.unitsMm}`);
    } catch (_) {}
    setFlowStep(FLOW.IDLE);
    setCurrentPtIdx(-1);
    setManualIdx(-1);
    setProgress(0);
    setStatus('⚠️ Leveling aborted.');
    setManualStatus('Aborted.');
  }, []);

  // ─────────────────────────────────────────────────────────────────────────────
  // Reset (clear mesh data, go back to idle)
  // ─────────────────────────────────────────────────────────────────────────────
  const resetFlow = useCallback(() => {
    if (!confirm('Clear all leveling data and start over?')) return;
    setMesh([]);
    setPcbOrigin(null);
    setFlowStep(FLOW.IDLE);
    setProgress(0);
    setCurrentPtIdx(-1);
    setManualIdx(-1);
    setStatus('');
  }, []);

  // ── Derived ─────────────────────────────────────────────────────────────────
  const calibratedCount = mesh.filter(p => p.zParam !== 0).length;
  const meshCalibrated  = calibratedCount === mesh.length && mesh.length > 0;
  const zVals  = mesh.filter(p => p.zParam !== 0).map(p => p.zParam);
  const zRange = zVals.length >= 2
    ? (Math.max(...zVals) - Math.min(...zVals)).toFixed(3)
    : null;

  // ─────────────────────────────────────────────────────────────────────────────
  // Render
  // ─────────────────────────────────────────────────────────────────────────────

  const probePointRow = (pt, idx) => {
    const isActive  = currentPtIdx === idx;
    const isDone    = pt.zParam !== 0;
    const dotColor  = isActive ? '#ffaa00' : isDone ? '#00c49a' : '#444';
    return (
      <tr key={pt.id} style={{ borderTop: '1px solid #2a2a2a',
        background: isActive ? 'rgba(255,170,0,0.10)' : 'transparent' }}>
        <td style={{ padding: '5px 8px' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <span style={{ width: 10, height: 10, borderRadius: '50%', background: dotColor,
              boxShadow: isActive ? '0 0 6px #ffaa00' : 'none', flexShrink: 0 }} />
            <span style={{ fontSize: '0.85em' }}>{pt.name}</span>
          </span>
        </td>
        <td style={{ padding: '5px 8px', fontFamily: 'monospace', fontSize: '0.82em', color: '#aaa' }}>
          {pt.x?.toFixed(2) ?? '—'}, {pt.y?.toFixed(2) ?? '—'}
        </td>
        <td style={{ padding: '5px 8px', fontWeight: 'bold', fontFamily: 'monospace',
          color: isActive ? '#ffaa00' : isDone ? '#00c49a' : '#555' }}>
          {isDone ? `${pt.zParam.toFixed(3)} mm` : isActive ? '…' : '—'}
        </td>
      </tr>
    );
  };

  return (
    <div style={{ padding: '15px', color: '#ccc', maxWidth: 520 }}>

      {/* ── Header ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4 }}>
        <div>
          <h3 style={{ color: '#00c49a', margin: 0 }}>🔧 PCB Surface Leveling</h3>
          <p style={{ fontSize: '0.8em', color: '#666', margin: '4px 0 0 0' }}>
            Probes the actual PCB surface so the nozzle maintains a constant
            gap even when the board is slightly warped or tilted.
          </p>
        </div>
        {flowStep !== FLOW.IDLE && (
          <button onClick={resetFlow}
            style={{ fontSize: '0.75em', padding: '4px 10px', background: '#2a1010',
              border: '1px solid #c0392b', color: '#c0392b', borderRadius: 4, cursor: 'pointer' }}>
            ✕ Reset
          </button>
        )}
      </div>

      {/* ── Mesh summary badge ── */}
      {mesh.length > 0 && (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12, marginTop: 8 }}>
          <span style={{ fontSize: '0.78em', padding: '3px 8px', borderRadius: 10,
            background: meshCalibrated ? '#0d3320' : '#1a2a1a',
            border: `1px solid ${meshCalibrated ? '#00c49a' : '#3a5a3a'}`,
            color: meshCalibrated ? '#00c49a' : '#5a9a5a' }}>
            {calibratedCount}/{mesh.length} points probed
          </span>
          {zRange && (
            <span style={{ fontSize: '0.78em', padding: '3px 8px', borderRadius: 10,
              background: '#1a1a00', border: '1px solid #555500', color: '#cccc00' }}>
              PCB warp: {zRange} mm
            </span>
          )}
          {meshCalibrated && (
            <span style={{ fontSize: '0.78em', padding: '3px 8px', borderRadius: 10,
              background: '#001a2a', border: '1px solid #005588', color: '#00aaff' }}>
              ✅ Z-compensation active
            </span>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          FLOW: IDLE — show start button + settings
      ════════════════════════════════════════════════════════════════════════ */}
      {flowStep === FLOW.IDLE && (
        <div>
          {/* Mode selector */}
          <div style={{ display: 'flex', marginBottom: 12, border: '1px solid #333', borderRadius: 6, overflow: 'hidden' }}>
            {['auto', 'manual'].map(m => (
              <button key={m} onClick={() => setProbeMode(m)}
                style={{ flex: 1, padding: 8, border: 'none', cursor: 'pointer',
                  background: probeMode === m ? '#00c49a' : '#1e1e1e',
                  color:      probeMode === m ? '#000'    : '#aaa',
                  fontWeight: probeMode === m ? 'bold'    : 'normal', fontSize: '0.88em' }}>
                {m === 'auto' ? '⚡ Auto (pressure sensor)' : '🖐 Manual (jog)'}
              </button>
            ))}
          </div>

          {/* Settings */}
          <div style={{ background: '#131320', border: '1px solid #1a2a4a', borderRadius: 8,
            padding: 12, marginBottom: 14 }}>
            <h4 style={{ margin: '0 0 10px 0', color: '#64b5f6', fontSize: '0.88em' }}>
              ⚙️ {probeMode === 'auto' ? 'Auto-Probe' : 'Manual'} Settings
            </h4>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              <Field label="Start Z (mm)"        value={probeStartZ}   onChange={setProbeStartZ}   step={0.5}  min={0}    max={20}  unit="mm" />
              <Field label="Edge Inset (mm)"      value={edgeInset}     onChange={setEdgeInset}     step={1}    min={0}    max={30}  unit="mm" />
              <Field label="Dispense Gap (mm)"    value={dispensingGap} onChange={setDispensingGap} step={0.05} min={0}    max={2}   unit="mm" />
              <Field label="Travel Lift (mm)"     value={liftHeight}    onChange={setLiftHeight}    step={0.5}  min={1}    max={20}  unit="mm" />
              <Field label="XY Speed (mm/min)"   value={xySpeed}       onChange={setXySpeed}       step={50}   min={50}   max={1000} unit="mm/min" />
              {probeMode === 'auto' && <>
                <Field label="Step Size (mm)"       value={stepSize}      onChange={setStepSize}      step={0.025} min={0.025} max={0.5} unit="mm" />
                <Field label="Speed (mm/min)"        value={probeSpeed}    onChange={setProbeSpeed}    step={10}   min={10}   max={300} unit="mm/min" />
                <Field label="Max Depth (mm)"        value={maxDepth}      onChange={setMaxDepth}      step={0.5}  min={-20}  max={0}   unit="mm" />
              </>}
            </div>
          </div>

          {/* Precondition hints */}
          <div style={{ marginBottom: 12, fontSize: '0.8em' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
              <span style={{ color: isConnected ? '#00c49a' : '#cc4400' }}>
                {isConnected ? '✅' : '❌'}
              </span>
              <span style={{ color: isConnected ? '#aaa' : '#cc6600' }}>
                {isConnected ? 'Machine connected' : 'Machine not connected'}
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ color: boardOutline ? '#00c49a' : '#cc4400' }}>
                {boardOutline ? '✅' : '❌'}
              </span>
              <span style={{ color: boardOutline ? '#aaa' : '#cc6600' }}>
                {boardOutline
                  ? `Board outline loaded (${(boardOutline.width ?? 0).toFixed(1)} × ${(boardOutline.height ?? 0).toFixed(1)} mm)`
                  : 'No board outline loaded — load a Gerber with an outline/edge layer'}
              </span>
            </div>
          </div>

          <Btn onClick={startLevelingFlow}
            disabled={!isConnected || !boardOutline}
            style={{ width: '100%' }}>
            🚀 Start PCB Leveling
          </Btn>

          {mesh.length > 0 && calibratedCount > 0 && (
            <div style={{ marginTop: 12, background: '#1a1a1a', borderRadius: 6,
              padding: 10, border: '1px solid #333' }}>
              <h4 style={{ margin: '0 0 8px 0', fontSize: '0.85em', color: '#888' }}>
                Previous Calibration
              </h4>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82em' }}>
                <thead>
                  <tr style={{ color: '#555', textAlign: 'left', borderBottom: '1px solid #2a2a2a' }}>
                    <th style={{ padding: '3px 8px' }}>Point</th>
                    <th style={{ padding: '3px 8px' }}>Machine XY</th>
                    <th style={{ padding: '3px 8px' }}>Dispense Z</th>
                  </tr>
                </thead>
                <tbody>{mesh.map(probePointRow)}</tbody>
              </table>
              <HeightMapVisualizer mesh={mesh} boardOutline={boardOutline} />
            </div>
          )}
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          FLOW: ANCHOR — user jogs to PCB bottom-left corner
      ════════════════════════════════════════════════════════════════════════ */}
      {flowStep === FLOW.ANCHOR && (
        <div>
          <div style={{ background: '#0d1f0d', border: '1px solid #1a4a1a',
            borderRadius: 8, padding: 14, marginBottom: 12 }}>
            <h4 style={{ color: '#00c49a', margin: '0 0 8px 0', fontSize: '0.95em' }}>
              📍 Step 1 of 2 — Set PCB Origin
            </h4>
            <p style={{ fontSize: '0.85em', color: '#aaa', margin: '0 0 10px 0', lineHeight: 1.6 }}>
              Jog the nozzle to the <strong style={{ color: '#fff' }}>bottom-left corner</strong> of
              your PCB. The nozzle tip should <em>just touch</em> the board surface at that corner.
              <br /><br />
              This tells the machine where the PCB is sitting on the bed.
              All 5 probe points will be calculated from this position.
            </p>

            {/* Live position readout */}
            <div style={{ display: 'flex', gap: 12, fontFamily: 'monospace', fontSize: '0.85em',
              background: '#111', padding: '6px 10px', borderRadius: 4, marginBottom: 10 }}>
              <span>X <strong style={{ color: '#0f0' }}>{machinePosition.x.toFixed(3)}</strong></span>
              <span>Y <strong style={{ color: '#0f0' }}>{machinePosition.y.toFixed(3)}</strong></span>
              <span>Z <strong style={{ color: '#0f0' }}>{machinePosition.z.toFixed(3)}</strong></span>
            </div>

            <InlineJog onSend={send} disabled={!isConnected} xySpeed={xySpeed} />
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            <Btn onClick={confirmPcbOrigin} disabled={!isConnected} style={{ flex: 1 }}>
              ✅ Confirm PCB Origin — Start Probing
            </Btn>
            <Btn onClick={abortFlow} color="#c0392b" textColor="#fff" style={{ width: 90 }}>
              Cancel
            </Btn>
          </div>

          <p style={{ fontSize: '0.75em', color: '#555', marginTop: 8 }}>
            Tip: use 0.1 mm steps for fine Z positioning. The exact X/Y corner
            position sets the coordinate origin for all subsequent probe points.
          </p>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          FLOW: PROBING — auto or manual probe in progress
      ════════════════════════════════════════════════════════════════════════ */}
      {flowStep === FLOW.PROBING && (
        <div>
          <div style={{ background: '#0d1926', border: '1px solid #1a3050',
            borderRadius: 8, padding: 12, marginBottom: 12 }}>
            <h4 style={{ color: '#64b5f6', margin: '0 0 8px 0', fontSize: '0.9em' }}>
              🔍 Step 2 of 2 — Probing PCB Surface ({probeMode === 'auto' ? 'Auto' : 'Manual'})
            </h4>

            {/* Progress bar */}
            <div style={{ height: 6, background: '#333', borderRadius: 3, overflow: 'hidden', marginBottom: 8 }}>
              <div style={{ height: '100%', width: `${progress}%`,
                background: '#00c49a', transition: 'width 0.5s ease' }} />
            </div>
            <div style={{ fontSize: '0.78em', color: '#ffaa00', padding: '7px 10px',
              background: '#1a1100', borderRadius: 4, border: '1px solid #443300',
              minHeight: 32, lineHeight: 1.5 }}>
              {statusMsg || 'Starting…'}
            </div>
          </div>

          {/* Points table — live status */}
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85em',
            background: '#1a1a1a', borderRadius: 8, overflow: 'hidden', marginBottom: 12 }}>
            <thead>
              <tr style={{ color: '#555', textAlign: 'left', borderBottom: '1px solid #2a2a2a',
                background: '#111' }}>
                <th style={{ padding: '5px 8px' }}>Point</th>
                <th style={{ padding: '5px 8px' }}>Machine XY</th>
                <th style={{ padding: '5px 8px' }}>Dispense Z</th>
              </tr>
            </thead>
            <tbody>{mesh.map(probePointRow)}</tbody>
          </table>

          {/* Manual: live Z + Save button */}
          {probeMode === 'manual' && manualIdx >= 0 && (
            <div style={{ background: '#1a1100', border: '1px solid #443300',
              borderRadius: 6, padding: 12, marginBottom: 10 }}>
              <div style={{ fontSize: '0.85em', color: '#ffaa00', marginBottom: 8 }}>
                {manualStatus}
              </div>
              <div style={{ fontFamily: 'monospace', fontSize: '0.9em', marginBottom: 10 }}>
                Current Z: <strong style={{ color: '#fff' }}>
                  {machinePosition.z?.toFixed(3)}
                </strong>
                <span style={{ color: '#666', marginLeft: 8 }}>
                  → will save as {(machinePosition.z + dispensingGap).toFixed(3)} mm
                  (+{dispensingGap} mm gap)
                </span>
              </div>
              <InlineJog onSend={send} disabled={!isConnected} xySpeed={xySpeed} />
              <Btn onClick={saveManualZ} style={{ marginTop: 10, width: '100%' }}>
                💾 Save Z & Move to Next Point
              </Btn>
            </div>
          )}

          <Btn onClick={abortFlow} color="#c0392b" textColor="#fff" style={{ width: '100%' }}>
            ■ Abort Probing
          </Btn>
        </div>
      )}

      {/* ════════════════════════════════════════════════════════════════════════
          FLOW: DONE
      ════════════════════════════════════════════════════════════════════════ */}
      {flowStep === FLOW.DONE && (
        <div>
          <div style={{ background: '#0d3320', border: '1px solid #00c49a',
            borderRadius: 8, padding: 14, marginBottom: 14, textAlign: 'center' }}>
            <div style={{ fontSize: '2em', marginBottom: 6 }}>✅</div>
            <h4 style={{ color: '#00c49a', margin: '0 0 6px 0' }}>PCB Leveling Complete</h4>
            <p style={{ fontSize: '0.85em', color: '#aaa', margin: 0 }}>
              {calibratedCount} points probed.
              {zRange && ` PCB warp: ${zRange} mm.`}
              {' '}Z-compensation is now active — the nozzle height will auto-adjust
              across the board during dispensing.
            </p>
          </div>

          {/* Final mesh table */}
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85em',
            background: '#1a1a1a', borderRadius: 8, overflow: 'hidden', marginBottom: 14 }}>
            <thead>
              <tr style={{ color: '#555', textAlign: 'left', borderBottom: '1px solid #2a2a2a', background: '#111' }}>
                <th style={{ padding: '5px 8px' }}>Point</th>
                <th style={{ padding: '5px 8px' }}>Machine XY</th>
                <th style={{ padding: '5px 8px' }}>Dispense Z</th>
              </tr>
            </thead>
            <tbody>{mesh.map(probePointRow)}</tbody>
          </table>

          <HeightMapVisualizer mesh={mesh} boardOutline={boardOutline} />

          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <Btn onClick={() => setFlowStep(FLOW.IDLE)} color="#1565c0" textColor="#fff" style={{ flex: 1 }}>
              ← Back to Settings
            </Btn>
            <Btn onClick={resetFlow} color="#2a1010" textColor="#c0392b" style={{ flex: 1 }}>
              🗑 Clear & Re-calibrate
            </Btn>
          </div>
        </div>
      )}

      {/* ── How it works note (always visible at bottom) ── */}
      {flowStep === FLOW.IDLE && (
        <div style={{ marginTop: 14, padding: 10, background: '#0d1926',
          border: '1px solid #1a3050', borderRadius: 6, fontSize: '0.76em', color: '#5588aa',
          lineHeight: 1.6 }}>
          <strong>How it works:</strong> You jog the nozzle to the PCB bottom-left corner once to
          anchor the coordinate system. The machine then automatically drives to all 5 points
          on the PCB surface (4 corners + centre), probes the Z height at each, and builds an
          interpolation mesh. During dispensing, <code style={{ background: '#111', padding: '1px 4px',
          borderRadius: 3 }}>getZOffsetForPoint(x,y)</code> returns the correct Z for any pad location.
          {probeMode === 'auto' && (
            <><br /><br />
            <strong>GRBL Surface Probing:</strong>
            <p style={{ margin: '4px 0 0 0', color: '#adf', fontSize: '0.92em' }}>
              Communicates with GRBL via real-time status queries (<code>?</code>).
              When the touch sensor contacts the board, GRBL reports <code>Pn:Z</code> (or <code>Pn:P</code>),
              which triggers contact detection and records the surface Z height.
            </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}